angular.module('app', ['ngCookies'])
.config(function ($controllerProvider, $cookiesProvider, itemProvider) {
  $controllerProvider.allowGlobals();
  $cookiesProvider.defaults.path = '/';

  itemProvider.defaults.name = "John";

})
.run(function(version, $rootScope) {
  $rootScope.version = version.Version;
})
.provider('item', [function () {
  
  var defaults = this.defaults = {};

  this.$get = [function() {
    return {
        "name": defaults.name
    };
  }];
}])
.provider('item1', [function () {

  // XXXX

  this.$get = [function() {
    return {
      "name": "Will"
    };
  }];
}])
.service('item3', [function () {
  
  this.name = "Will";

}])
.factory('item2', [function () {

  // OOOOO

  return {
    "name": "Will"
  };
}])
.value('item4', {
  "name": "Will"
})

.directive('addCart', [function () {
  return {
    templateUrl: 'addCart.html',
    restrict: 'AE'
  };
}])












