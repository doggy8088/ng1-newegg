(function() {

	angular.module('app')
	.value('version', {
		'Main': 1,
		"Minor": 0,
		"Version": '1.0.0'
	});

})();